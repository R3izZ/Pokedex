import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import ListaPokemons from './components/List';
import DetalhesPokemon from './components/Details';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="ListaPokemons">
        <Stack.Screen
          name="ListaPokemons"
          component={ListaPokemons}
          options={{ title: 'Pokémon List' }}
        />
        <Stack.Screen
          name="DetalhesPokemon"
          component={DetalhesPokemon}
          options={{ title: 'Pokémon Details' }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}


