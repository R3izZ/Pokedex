import React, { useState, useEffect } from 'react';
import { ActivityIndicator, FlatList, Image, TouchableOpacity } from 'react-native';
import { Container, ListItem, PokemonName } from './styled-components';

const List = ({ navigation }) => {
  const [loading, setLoading] = useState(true);
  const [pokemonList, setPokemonList] = useState([]);

  useEffect(() => {
    const fetchPokemonList = async () => {
      try {
        const response = await fetch('https://pokeapi.co/api/v2/pokemon');
        const data = await response.json();
        setPokemonList(data.results);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching Pokemon list:', error);
      }
    };

    fetchPokemonList();
  }, []);

  const handlePokemonPress = async (pokemon) => {
    try {
      const response = await fetch(pokemon.url);
      const data = await response.json();
      navigation.navigate('DetalhesPokemon', { pokemon: data });
    } catch (error) {
      console.error('Error fetching Pokemon data:', error);
    }
  };

  return (
    <Container>
      {loading ? (
        <ActivityIndicator size={'large'} />
      ) : (
        <FlatList
          data={pokemonList}
          keyExtractor={(item) => item.name}
          renderItem={({ item }) => (
            <TouchableOpacity onPress={() => handlePokemonPress(item)}>
              <ListItem>
                <Image
                  style={{ width: 50, height: 50 }}
                  source={{ uri: `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${item.url.split('/')[6].replace(/\D/g,'')}.png` }}
                />
                <PokemonName>{item.name}</PokemonName>
              </ListItem>
            </TouchableOpacity>
          )}
        />
      )}
    </Container>
  );
};

export default List;


