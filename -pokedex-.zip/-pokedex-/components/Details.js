import React from 'react';
import { View, Image, Share } from 'react-native';
import {
  Container1,
  StatsContainer,
  Stat,
  StatLabel,
  StatValue,
  ProgressBar,
  ProgressFill,
  StyledButton,
  ButtonText,
  InfoLabel,
  InfoValue,
  Divider,
  BadgeButton1,
  BadgeButton2,
  BadgeButtonText,
  BadgeContainer,
} from './styled-components';

const Details = ({ route }) => {
  const { pokemon } = route.params;

  const sharePokemonDetails = () => {
    const message = `Check out the stats for ${pokemon.name}:
    HP: ${pokemon.stats[0].base_stat}
    Attack: ${pokemon.stats[1].base_stat}
    Defense: ${pokemon.stats[2].base_stat}
    Height: ${pokemon.height / 10} m
    Weight: ${pokemon.weight / 10} kg`;

    Share.share({ message });
  };

  return (
    <Container1>
      <BadgeContainer>
        <BadgeButton1 activeOpacity={0.7}>
          <BadgeButtonText>BADGE</BadgeButtonText>
        </BadgeButton1>
        <BadgeButton2 activeOpacity={0.7}>
          <BadgeButtonText>BADGE</BadgeButtonText>
        </BadgeButton2>
      </BadgeContainer>
      <Image
        style={{ width: '100%', height: 350, resizeMode: 'stretch' }}
        source={{ uri: pokemon.sprites.other['official-artwork'].front_default }}
      />
      <StatsContainer>
        <View style={{ flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginBottom: 20 }}>
          <View style={{ flexDirection: 'column-reverse', alignItems: 'center' }}>
            <InfoLabel>Height</InfoLabel>
            <InfoValue>{pokemon.height / 10} m</InfoValue>
          </View>
          <Divider />
          <View style={{ flexDirection: 'column-reverse', alignItems: 'center' }}>
            <InfoLabel>Weight</InfoLabel>
            <InfoValue>{pokemon.weight / 10} kg</InfoValue>
          </View>
        </View>
        <Stat>
          <StatLabel>HP</StatLabel>
          <ProgressBar>
            <ProgressFill width={`${(pokemon.stats[0].base_stat / 100) * 100}%`} />
          </ProgressBar>
          <StatValue>{pokemon.stats[0].base_stat}</StatValue>
        </Stat>
        <Stat>
          <StatLabel>Attack</StatLabel>
          <ProgressBar>
            <ProgressFill width={`${(pokemon.stats[1].base_stat / 100) * 100}%`} />
          </ProgressBar>
          <StatValue>{pokemon.stats[1].base_stat}</StatValue>
        </Stat>
        <Stat>
          <StatLabel>Defense</StatLabel>
          <ProgressBar>
            <ProgressFill width={`${(pokemon.stats[2].base_stat / 100) * 100}%`} />
          </ProgressBar>
          <StatValue>{pokemon.stats[2].base_stat}</StatValue>
        </Stat>
      </StatsContainer>
      <StyledButton onPress={sharePokemonDetails}>
        <ButtonText>Compartilhar</ButtonText>
      </StyledButton>
    </Container1>
  );
};

export default Details;


