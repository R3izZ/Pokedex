import styled from 'styled-components/native';

export const Container = styled.View`
  flex: 1;
  padding: 20px;
  background-color: #97CBAF;
`;
export const Container1 = styled.View`
  flex: 1;
  padding: 20px;
  background-color: #97CBAd;
`;

export const ListItem = styled.View`
  flex-direction: row;
  align-items: center;
  padding: 12px;
  background: #fff;
  border-radius: 40px;
  margin-bottom: 10px;
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.09);
`;

export const PokemonName = styled.Text`
  font-size: 21px;
  margin-left: 10px;
  font-family: 'Overpass';
  font-weight: 600;
`;

export const StatsContainer = styled.View`
  background: #FFFFFF;
  border-radius: 30px;
  padding: 20px;
  margin: 1px;
`;

export const Stat = styled.View`
  flex-direction: row;
  align-items: center;
  margin-bottom: 10px;
  width: 100%;
`;

export const StatLabel = styled.Text`
  font-size: 14px;
  font-family: 'Overpass';
  font-weight: 400;
  color: #000;
  margin-right: 10px;
  flex: 1;
`;

export const StatValue = styled.Text`
  font-size: 14px;
  font-family: 'Overpass';
  font-weight: 600;
  color: #222;
  margin-left: 10px;
`;

export const ProgressBar = styled.View`
  flex: 4;
  height: 10px;
  background: #e5e5e5;
  border-radius: 8px;
  margin-right: 10px;
  justify-content: center;
`;

export const ProgressFill = styled.View`
  height: 100%;
  background: #478070;
  border-radius: 8px;
`;

export const StyledButton = styled.TouchableOpacity`
  background-color: #478070;
  padding: 10px 20px;
  border-radius: 8px;
  margin-top: 20px;
  align-items: center;
`;

export const ButtonText = styled.Text`
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 600;
  font-size: 20px;
  line-height: 22px;
  text-align: center;
  color: #ffffff;
`;

export const InfoLabel = styled.Text`
  font-size: 15px;
  font-family: 'Overpass';
  font-weight: 400;
  color: #000;
  text-transform: uppercase;
`;

export const InfoValue = styled.Text`
  font-size: 30px;
  font-family: 'Overpass';
  font-weight: 600;
  color: #222;
`;

export const Divider = styled.View`
  width: 1px;
  height: 50px;
  background-color: #1111;
  margin: 0 20px;
`;

export const BadgeContainer = styled.View`
  flex-direction: row;
  justify-content: flex-start;
  margin-bottom: 20px;
`;

export const BadgeButton1 = styled.TouchableOpacity`
  background-color: #478070;
  padding: 10px 20px;
  border-radius: 8px;
  margin-right: 10px;
`;

export const BadgeButton2 = styled.TouchableOpacity`
  background-color: #565656;
  padding: 10px 20px;
  border-radius: 8px;
`;

export const BadgeButtonText = styled.Text`
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 600;
  font-size: 16px;
  line-height: 22px;
  text-align: center;
  color: #ffffff;
`;

